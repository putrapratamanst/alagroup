jQuery(document).ready( function($) {
	// Course Write Panel
	if ( jQuery( '#course-certificate-template-options' ) ) { jQuery( '#course-certificate-template-options' ).select2(); }
});